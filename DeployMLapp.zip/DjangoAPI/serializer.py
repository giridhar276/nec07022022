#Django-REST framework provides a class named Serializers to build your own serializers. 
#Serializers in Django REST Framework are responsible for converting objects into data types understandable by javascript and front-end frameworks
from rest_framework import serializers
from .models import Customer

class CustomerSerializers(serializers.ModelSerializer):
    class meta:
        model=Customer
        fields='__all__'